<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_zurite',
    'db_user' => 'sonccoc_zurite',
    'db_pass' => '$ordenzurite'
);
?>
