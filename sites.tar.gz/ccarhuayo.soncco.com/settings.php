<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_ccarhua',
    'db_user' => 'sonccoc_ccarhua',
    'db_pass' => '$ordencarhua'
);
?>
