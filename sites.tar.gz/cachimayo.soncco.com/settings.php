<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_cachi',
    'db_user' => 'sonccoc_cachi',
    'db_pass' => '$cachiorden'
);
?>
