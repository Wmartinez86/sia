<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_lares',
    'db_user' => 'sonccoc_lares',
    'db_pass' => '$ordenlares'
);
?>
