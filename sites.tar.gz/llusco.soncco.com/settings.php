<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_llusco',
    'db_user' => 'sonccoc_llusco',
    'db_pass' => '$ordenllusco'
);
?>
