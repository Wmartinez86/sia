<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_salvador',
    'db_user' => 'sonccoc_salvador',
    'db_pass' => '$ordensalvador'
);
?>
