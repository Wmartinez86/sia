<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_quinota',
    'db_user' => 'sonccoc_quinota',
    'db_pass' => '$ordenquinota'
);
?>
