<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_ollanta',
    'db_user' => 'sonccoc_ollanta',
    'db_pass' => '$ollantaorden'
);
?>
