<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_pucyura',
    'db_user' => 'sonccoc_pucyura',
    'db_pass' => '$ordenpucyura'
);
?>
