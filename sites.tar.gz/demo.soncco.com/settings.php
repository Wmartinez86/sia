<?php

$db_params = array(
    'db_host' => 'localhost',
    'db_name' => 'sonccoc_ordenes',
    'db_user' => 'sonccoc_ordenes',
    'db_pass' => '$ordenes'
);
?>
